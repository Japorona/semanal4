import { Component } from '@angular/core';

@Component({
  selector: 'app-editoradetails',
  standalone: true,
  imports: [],
  templateUrl: './editoradetails.component.html',
  styleUrl: './editoradetails.component.scss'
})
export class EditoradetailsComponent {

}
