import { Component } from '@angular/core';

@Component({
  selector: 'app-editoralist',
  standalone: true,
  imports: [],
  templateUrl: './editoralist.component.html',
  styleUrl: './editoralist.component.scss'
})
export class EditoralistComponent {

}
