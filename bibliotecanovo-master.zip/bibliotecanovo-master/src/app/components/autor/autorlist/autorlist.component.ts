import { Component } from '@angular/core';

@Component({
  selector: 'app-autorlist',
  standalone: true,
  imports: [],
  templateUrl: './autorlist.component.html',
  styleUrl: './autorlist.component.scss'
})
export class AutorlistComponent {

}
