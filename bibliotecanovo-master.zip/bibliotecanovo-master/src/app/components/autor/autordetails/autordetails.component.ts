import { Component } from '@angular/core';

@Component({
  selector: 'app-autordetails',
  standalone: true,
  imports: [],
  templateUrl: './autordetails.component.html',
  styleUrl: './autordetails.component.scss'
})
export class AutordetailsComponent {

}
