export class Editora {
    
    id!: number;
    nome!: string;
}
