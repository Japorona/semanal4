import { Autor } from './autor';

describe('Autor', () => {
  it('should create an instance', () => {
    expect(new Autor()).toBeTruthy();
  });
});
