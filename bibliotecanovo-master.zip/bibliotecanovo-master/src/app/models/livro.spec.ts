import { Livro } from './livro';

describe('Livro', () => {
  it('should create an instance', () => {
    expect(new Livro()).toBeTruthy();
  });
});
