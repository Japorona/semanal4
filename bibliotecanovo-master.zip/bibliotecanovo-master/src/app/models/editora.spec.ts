import { Editora } from './editora';

describe('Editora', () => {
  it('should create an instance', () => {
    expect(new Editora()).toBeTruthy();
  });
});
