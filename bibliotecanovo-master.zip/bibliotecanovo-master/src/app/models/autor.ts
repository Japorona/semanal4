export class Autor {

    id!: number;
    nome!: string;
}
