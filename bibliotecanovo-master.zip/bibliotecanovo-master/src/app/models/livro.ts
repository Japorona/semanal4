import { Autor } from "./autor";

export class Livro {

    id!: number;
    nome!: string;
    autor!: Autor;
}
